package ej2_MulticastConMetodos;
import java.net.*;
import java.io.*;
import java.util.logging.*;

public class Servidor {
    private InetAddress direccion;
    private MulticastSocket servidor;
    
    Servidor(){
        try {
            this.direccion=InetAddress.getByName("224.0.0.3");
            try {
                servidor=new MulticastSocket(4000);
            } catch (IOException ex) {Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);}
        } catch (UnknownHostException ex) {Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public void unirseGrupo(){
        try {
            servidor.joinGroup(direccion);
        } catch (IOException ex){Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public void recibirMensaje(){
        try {
            byte buffer[]=new byte[1024];
            DatagramPacket p_recibir=new DatagramPacket(buffer, buffer.length);
            servidor.receive(p_recibir);
            String recibido=new String(buffer, 0, p_recibir.getLength());
            System.out.println("Recibido: "+recibido);
        } catch (IOException ex) {Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public static void main(String args[]){
        Servidor s=new Servidor();
        s.unirseGrupo();
        while(true){
            s.recibirMensaje();
        }
    }
}
