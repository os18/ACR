package ej2_MulticastConMetodos;
import java.net.*;
import java.io.*;
import java.util.logging.*;

public class Cliente {
    private InetAddress direccion;
    private MulticastSocket cliente;
    
    Cliente(){
        try {
            direccion=InetAddress.getByName("224.0.0.3");
            try {
                cliente=new MulticastSocket();
            } catch(IOException ex){Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);}
        } catch(UnknownHostException ex){Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public void unirseGrupo(){
        try {
            cliente.joinGroup(direccion);
        } catch(IOException ex){Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public void enviarMensaje(){
        try{
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            String enviar=br.readLine();
            byte buf[]=enviar.getBytes();
            DatagramPacket p_enviar=new DatagramPacket(buf, buf.length, direccion, 4000);
            cliente.send(p_enviar);
        }catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public static void main(String args[]){
        Cliente c=new Cliente();
        c.unirseGrupo();
        while(true){
            c.enviarMensaje();
        }
    }
}
