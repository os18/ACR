package Datagrama_conMetodos;
import java.io.*;
import java.net.*;

public class Cliente {
    private DatagramSocket cliente;
    
    Cliente(){
        try {
            cliente=new DatagramSocket();
        } catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void enviar(){
        try {
            byte[] buffer="pacatelas".getBytes();
            DatagramPacket p_enviar=new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(), 5000);
            cliente.send(p_enviar);
        } catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void recibir(){
        try {
            byte[] buffer=new byte[1024];
            DatagramPacket p_recibir=new DatagramPacket(buffer, buffer.length);
            cliente.receive(p_recibir);
            String recibe = new String(buffer);
            System.out.println(recibe);
        } catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public static void main(String args[]){
        Cliente c=new Cliente();
        c.enviar();
        c.recibir();
    }
}
