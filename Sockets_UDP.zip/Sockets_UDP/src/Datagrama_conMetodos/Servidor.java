package Datagrama_conMetodos;
import java.net.*;
import java.io.*;

public class Servidor {
    private DatagramSocket servidor;
    private DatagramPacket p_recibir;
    
    Servidor(){
        try{
            servidor = new DatagramSocket(5000);
        }catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void recibir(){
        try {
            byte[] buffer1=new byte[1024];
            p_recibir = new DatagramPacket(buffer1, buffer1.length);
            servidor.receive(p_recibir);
            System.out.println("recibido: "+p_recibir.getData());
        } catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void enviar(){
        try {
            DatagramPacket p_enviar=new DatagramPacket(p_recibir.getData(), p_recibir.getLength(), p_recibir.getAddress(), p_recibir.getPort());
            servidor.send(p_enviar);
        } catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public static void main(String args[]){
        Servidor s=new Servidor();
        s.recibir();
        s.enviar();
    }
}
