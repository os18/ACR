package Ej2_chatMulticast;
import java.net.*;
import java.io.*;

public class Cliente {
    public static void main(String[] args)throws Exception{
        InetAddress direccion = InetAddress.getByName("224.0.0.5"); //direccion del grupo
        try{
            MulticastSocket socket=new MulticastSocket(); //socket para conectarse
            while(true){
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); //enviar mensajes del cliente
                String mensaje=br.readLine();
                byte[] data = mensaje.getBytes();
                DatagramPacket paquete=new DatagramPacket(data, data.length, direccion, 4000); //enviarlos al puerto 4000 al grupo
                socket.send(paquete);//enviando
            }
        } catch(IOException e){System.out.println("Error:"+e.toString());}
    }
}