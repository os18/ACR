package Ej2_chatMulticast;
import java.net.*;
import java.io.*;

public class Servidor {
    public static void main(String[] args) throws Exception {
        InetAddress direccion = InetAddress.getByName("224.0.0.5"); //direccion de grupo
        try{
            MulticastSocket socket = new MulticastSocket(4000);//socketmulticast en el puerto 4000
            socket.joinGroup(direccion); //agregar el socket al grupo 
            while(true){
                byte buffer[] = new byte[1024]; //buffer para recibir
                DatagramPacket paquete = new DatagramPacket(buffer, buffer.length);
                socket.receive(paquete); //rcibiendo
                String mensaje = new String(buffer, 0, paquete.getLength()); //imprimir el mensaje recibido
                System.out.println("Recibido: "+mensaje);
            }
        } catch (IOException e){System.out.println("Error: "+e.toString());}
    }
}