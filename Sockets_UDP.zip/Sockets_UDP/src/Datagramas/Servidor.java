package Datagramas;
import java.io.*;
import java.net.*;

public class Servidor {
    public static void main(String args[]){
        try{
            DatagramSocket servidor=new DatagramSocket(5000); //un socket para servidor y dos paquetes (enviar y recibir)
            byte buffer[]=new byte[1024]; //buffer para recibir
            DatagramPacket P_recibir=new DatagramPacket(buffer, buffer.length); //recibiendo
            servidor.receive(P_recibir); 
            DatagramPacket P_enviar=new DatagramPacket(P_recibir.getData(), P_recibir.getLength(), P_recibir.getAddress(), P_recibir.getPort());
            servidor.send(P_enviar);//enviando
        }catch(IOException e){System.out.println(e.getMessage());}
    }
}