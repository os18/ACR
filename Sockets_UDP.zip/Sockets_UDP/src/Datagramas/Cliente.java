package Datagramas;
import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String args[]){
        try{
            DatagramSocket cliente=new DatagramSocket(); //se crea el datagram del cliente y dos paquetes (enviar y recibir)
            byte buffer[]="sdrasvitye".getBytes(); //el buffer que será enviado
            DatagramPacket P_enviar=new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(), 5000);
            cliente.send(P_enviar); //se envia el paquete
            byte b2[]=new byte[1024]; //buffer para recibir paquete
            DatagramPacket P_recibir=new DatagramPacket(b2,b2.length);
            cliente.receive(P_recibir); //recibiendo
            String recibe=new String(b2);//se imprime lo que se recibió
            System.out.println(recibe);
        }catch(IOException e){System.out.println(e.getMessage());}
    }
}