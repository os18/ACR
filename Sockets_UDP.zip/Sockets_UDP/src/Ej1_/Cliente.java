package Ej1_;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.logging.*;

public class Cliente {
    DatagramSocket cliente;
    BufferedInputStream bis;
    ArrayList<String> arch= new ArrayList<String>();
    
    Cliente(){
        try {
            cliente = new DatagramSocket();
        }catch (SocketException ex) {System.out.println(ex.getMessage());}
    }
    
    public void recibirSaludo(){
        try{            
            byte buffer[] = new byte[1024];
            DatagramPacket paqueteRecibir = new DatagramPacket(buffer, buffer.length);        
            cliente.receive(paqueteRecibir);
            String recibe = new String(buffer);
            System.out.println(recibe);
        }catch(SocketException ex){System.out.println(ex.getMessage());}catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void recibir(){
        try{
            byte buffer[] = new byte[1024];
            DatagramPacket paqueteRecibir = new DatagramPacket(buffer, buffer.length);        
            cliente.receive(paqueteRecibir);
            String recibe = new String(buffer);
            String[] ARCHIVOS = recibe.split("\n");
            for(int i=0; i<ARCHIVOS.length-1; i++){
                arch.add(ARCHIVOS[i]);
            }
            for(int i=0; i<arch.size(); i++){
                System.out.println(i+".-"+arch.get(i));
            }          
        }catch(SocketException ex){System.out.println(ex.getMessage());}catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void enviar(){
        try{
            byte buffer[] = new byte[1024];
            String archivo= "archivo.txt";
            File f= new File(archivo);
            bis= new BufferedInputStream(new FileInputStream(f));
            long size = f.length();
            System.out.println(String.valueOf(size));
            double numpaq=  (double) size/1024;
            int n=0;
            System.out.println(String.valueOf(numpaq));
            while (n < numpaq){
                bis.read(buffer);
                DatagramPacket paqueteEnviar = new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(), 5000);
                cliente.send(paqueteEnviar);
                n++;
                buffer= new byte[1024];
            }
            bis.close();
            System.out.println("Enviando al servidor");
        }catch (SocketException ex) {System.out.println(ex.getMessage());}catch (UnknownHostException e) {System.out.println(e.getMessage());}catch (IOException exe) {System.out.println(exe.getMessage());}
    }
    
    public void Ingresar(String nombre,  String contrasenia){
        try{
            String ingreso= nombre+","+contrasenia;
            byte buffer[]=ingreso.getBytes();
            DatagramPacket paqueteEnviar = new DatagramPacket(buffer, buffer.length, InetAddress.getLocalHost(),5000);
            cliente.send(paqueteEnviar);
            System.out.println("Ingresando...");
        } catch (IOException ex) {Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public static void main(String args[]){
        Cliente clien= new Cliente();
        clien.Ingresar("Osiris","123");
        clien.recibirSaludo();
        clien.recibir();  
    }
}