package Ej1_;

public class Usuarios {
    public String nombre, pass;
    
    public Usuarios(String nom, String pas){
        this.nombre=nom;
        this.pass=pas;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPass() {
        return pass;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}