package Ej1_;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.logging.*;

public class Servidor {
    DatagramSocket server;
    DatagramPacket paqueteRecibir;
    BufferedInputStream bis;
    BufferedOutputStream bos;
    String nombreCliente;
    ArrayList<Usuarios> usuarios = new ArrayList<Usuarios>();
    
    Servidor(){
        try {
            server = new DatagramSocket(5000);
        }catch (SocketException ex) {System.out.println(ex.getMessage()); }
    }
    
    public void enviar(){
        try {
            byte buffer[] = "Hola cliente ... :p".getBytes();
            DatagramPacket paqueteEnviar = new DatagramPacket(buffer, buffer.length,InetAddress.getLocalHost(), 5000);
            server.send(paqueteEnviar);  
        } catch(SocketException ex){System.out.println(ex.getMessage());} catch(UnknownHostException e) {System.out.println(e.getMessage());} catch(IOException exe){System.out.println(exe.getMessage());}
    }
    
    public void recibir(){
        try {
          FileWriter fw = new FileWriter(new File("/home/os/NetBeansProjects/Sockets_UDP/Archivirijillos"));
            byte buffer[] = new byte[1024];
            DatagramPacket paqueteRecibir = new DatagramPacket(buffer, buffer.length);
            int tamanio= paqueteRecibir.getLength();
            int n=0;
            String datos="";
            while(tamanio  > 0){   
                paqueteRecibir = new DatagramPacket(buffer, buffer.length);
                server.receive(paqueteRecibir);
                datos += (new String(paqueteRecibir.getData()));
                System.out.println(buffer);
                tamanio= paqueteRecibir.getLength();
                fw.write(datos);
                fw.flush();
                buffer= new byte[1024];
                n++;
            }
            fw.close();
        } catch (SocketException ex) {System.out.println(ex.getMessage());} catch (IOException e) {System.out.println(e.getMessage());}
    }
    
    public void registrar(String nom, String pass){
        Usuarios usu= new Usuarios(nom, pass);
        usuarios.add(usu);
    }
    
    public void validar(){
        try{
            byte buffer []= new byte[1024];//arreglo de bytes para que funcione el paquete hasta 8mil bytes
            paqueteRecibir=new DatagramPacket(buffer, buffer.length);
            server.receive(paqueteRecibir);
            String recibe = new String(buffer);
            String[] parts = recibe.split(",");
            String nom = parts[0]; // 123
            String pass = parts[1]; // 654321
            for(int i=0;i< usuarios.size();i++){
                Usuarios usu= usuarios.get(i);
                if((usu.getNombre()==nom) && (usu.getPass()==pass)){
                    System.out.println("Ya existe ese usuario");
                }else{
                    registrar(nom, pass);
                }
            }
            nombreCliente=nom;
        }catch(IOException ex){Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);}
    }
    
    public void EnviarSaludo(){
         try {
            String nombreArchivos="Hola: cliente "+ nombreCliente+"\n";
            nombreArchivos+="Archivos disponibles: \n";
            DatagramPacket paqueteEnviar;
            byte buffer[] = nombreArchivos.getBytes();
            paqueteEnviar = new DatagramPacket(buffer, buffer.length,paqueteRecibir.getAddress(),paqueteRecibir.getPort() );
            System.out.println("Enviando al cliente");
            server.send(paqueteEnviar);  
        } catch (SocketException ex) {System.out.println(ex.getMessage());} catch (UnknownHostException e) {System.out.println(e.getMessage());} catch (IOException exe) {System.out.println(exe.getMessage());}
    }
    
    public void Enviarmenu(){
           try {
            String path = "/home/os/NetBeansProjects/Sockets_UDP/Archivirijillos";
            String[] files = getArchivos( path );  
            String nombreArchivos="";
            if ( files != null ) {
                for ( int i = 0; i < files.length; i ++ ) {
                    String[] output = files[i].split("\\\\");
                    nombreArchivos+=output[output.length-1]+"\n";
                }
            }
            DatagramPacket paqueteEnviar;
            byte buffer[] = nombreArchivos.getBytes();
            paqueteEnviar = new DatagramPacket(buffer, buffer.length,paqueteRecibir.getAddress(),paqueteRecibir.getPort() );
            System.out.println("Enviando al cliente");
            server.send(paqueteEnviar);  
            server.close();
        } catch (SocketException ex) {System.out.println(ex.getMessage());
        } catch (UnknownHostException e) {System.out.println(e.getMessage());
        } catch (IOException exe) {System.out.println(exe.getMessage());}
    }
    
    public static String[] getArchivos( String dir_path ) {
        String[] arr_res = null;
        File f = new File( dir_path );
        if ( f.isDirectory( )) {
            ArrayList<String> res   = new ArrayList<>();
            File[] arr_content = f.listFiles();
            int size = arr_content.length;
            for ( int i = 0; i < size; i ++ ) {
                if ( arr_content[ i ].isFile( ))
                res.add( arr_content[ i ].toString( ));
            }
            arr_res = res.toArray( new String[ 0 ] );
        } else
        System.err.println("¡Path NO válido !");
        return arr_res;
    }
    
    public static void main(String args[]){
        Servidor serv= new Servidor();
        serv.validar();
        serv.EnviarSaludo();
        serv.Enviarmenu();
        try {
            Thread.sleep(1000);
        } catch (InterruptedException ex) { Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);} 
    }
}