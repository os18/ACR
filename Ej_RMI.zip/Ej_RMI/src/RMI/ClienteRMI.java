package RMI;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ClienteRMI {
    public static void main(String args[]){
        try{
            Registry reg=LocateRegistry.getRegistry("127.0.0.1", 1099);
            InterfazRemota rmiI;
            rmiI=(InterfazRemota)reg.lookup("Objeto remoto");
            System.out.println("suma"+rmiI.suma(1, 2));
        }catch(Exception ex){System.out.println(ex.getMessage());}
    }
}