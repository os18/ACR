package RMI;

import java.rmi.Remote;

public interface InterfazRemota extends Remote {
    public int suma (int a, int b) throws java.rmi.RemoteException; 
}