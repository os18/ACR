package RMI;
import java.io.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ObjetoRemoto extends UnicastRemoteObject implements InterfazRemota{
    public ObjetoRemoto()throws RemoteException{
        super();
    }
    
    public int suma(int a, int b)throws RemoteException{
        return a+b;
    }
}