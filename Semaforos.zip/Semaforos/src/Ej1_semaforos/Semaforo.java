package Ej1_semaforos;
import java.util.concurrent.*;

public class Semaforo {
    public static void main(String args[]){
        Semaphore sem= new Semaphore(3, true);//cantidad de hilos que va dejar pasar y el estado en el que está el semaforo
        
        Delorean c1 = new Delorean("Toyota", sem);
        Delorean c2 = new Delorean("bocho", sem);
        Delorean c3 = new Delorean("carro_invisible", sem);
        Delorean c4 = new Delorean("kia", sem);
        Delorean c5 = new Delorean("P-chan movil", sem);
        Delorean c6 = new Delorean("Honda", sem);
        Delorean c7 = new Delorean("Zoid", sem);
        
        Thread t1= new Thread(c1);
        Thread t2= new Thread(c2);
        Thread t3= new Thread(c3);
        Thread t4= new Thread(c4);
        Thread t5= new Thread(c5);
        Thread t6= new Thread(c6);
        Thread t7= new Thread(c7);
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();
    }
}