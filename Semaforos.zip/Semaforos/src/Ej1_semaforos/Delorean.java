package Ej1_semaforos;
import java.util.concurrent.Semaphore;

public class Delorean implements Runnable{
    String marca;
    private Semaphore s;
    
    public Delorean(String m, Semaphore s){
        this.marca=m;
        this.s=s;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    public void run(){
        try {
            s.acquire(); //básicamente un wait, una forma de sincronizar para dejar pasar varios hilos
            System.out.println(marca+" tiene luz verde");
            Thread.sleep(1000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }finally{
            s.release();
        }
    }
}