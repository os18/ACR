package EjercicioLocochon;
import java.net.*;
import java.io.*;
import java.util.*;

public class Servidor {
    private ServerSocket servidor;
    private Socket cliente;
    private String mensaje;
    private List<DireccionesYDominios> lista = new ArrayList<DireccionesYDominios>();
    
    Servidor(){
        try{
            this.servidor=new ServerSocket(3001);
            this.cliente=servidor.accept();
            this.mensaje="";
        } catch(IOException e){System.out.println(e.getMessage());}
        lista();
    }
    
    public void enviarMensaje(){
        try {
            DataOutputStream dos=new DataOutputStream(cliente.getOutputStream());
            dos.writeUTF("WTU?");
        } catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void recibirMensaje(){
        try {
            DataInputStream dis=new DataInputStream(cliente.getInputStream());
            mensaje=dis.readUTF();
            System.out.println(mensaje);
        } catch(IOException e){System.out.println(e.getMessage());}
        
    }

    public String getMensaje() {
        return mensaje;
    }
    
    public void lista(){
        DireccionesYDominios d1=new DireccionesYDominios("google.es", "66.249.93.104");
        DireccionesYDominios d2=new DireccionesYDominios("Firexox", "149.112.112.112");
        DireccionesYDominios d3=new DireccionesYDominios("Facebook", "149.112.112.112");
        DireccionesYDominios d4=new DireccionesYDominios("Telewisa", "149.112.112.112");
        DireccionesYDominios d5=new DireccionesYDominios("Ventaneando.net", "149.112.112.112");
        DireccionesYDominios d6=new DireccionesYDominios("Google", "8.8.8.8");
        DireccionesYDominios d7=new DireccionesYDominios("Macinperro", "142.102.102.112");
        DireccionesYDominios d8=new DireccionesYDominios("dominio8", "9.2.2.2");
        DireccionesYDominios d9=new DireccionesYDominios("dominio9", "4.1.1.1");
        DireccionesYDominios d0=new DireccionesYDominios("dominio10", "1.12.12.12");
        
        lista.add(d1);
        lista.add(d2);
        lista.add(d3);
        lista.add(d4);
        lista.add(d5);
        lista.add(d6);
        lista.add(d7);
        lista.add(d8);
        lista.add(d9);
        lista.add(d0);
    }
    
    public String buscarElemento(String elemento){
        String res="-1";
        for(int i=0; i<lista.size(); i++){
            if(lista.get(i).getDireccion().equals(elemento) || lista.get(i).getDominio().equals(elemento)){
                res = lista.get(i).toString();
                System.out.println(res);
            }
        }
        return res;
    }
    
    public void respuesta(String r){
        try {
            DataOutputStream dos=new DataOutputStream(cliente.getOutputStream());
            dos.writeUTF(r);
        } catch (IOException ex) {System.out.println(ex.getMessage());}
    }
    
    public static void main(String args[]){
        Servidor s=new Servidor();
        do{
            s.enviarMensaje();
            s.recibirMensaje();
            String resp = s.buscarElemento(s.getMensaje());
            s.respuesta(resp);
        }while(true);
    }
}