package EjercicioLocochon;
import java.net.*;
import java.io.*;

public class Cliente {
    private Socket cliente;
    private String mensaje;
    
    Cliente(){
        try{
            this.cliente=new Socket("127.0.0.1", 3001);
            this.mensaje="";
        }catch(IOException e){System.out.println(e.getMessage());}
    }

    public String getMensaje() {
        return mensaje;
    }
    
    public void enviarMensaje(){
        try{
            DataOutputStream dos=new DataOutputStream(cliente.getOutputStream());
            BufferedReader buffer=new BufferedReader(new InputStreamReader(System.in));
            mensaje=buffer.readLine();
            dos.writeUTF(mensaje);
        }catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void recibirMensaje(){
        try{
            DataInputStream dis=new DataInputStream(cliente.getInputStream());
            System.out.println(dis.readUTF());
        }catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public static void main(String args[]){
        Cliente c=new Cliente();
        do{
            c.recibirMensaje();
            c.enviarMensaje();
            c.recibirMensaje();
        }while(!c.getMensaje().startsWith("fin"));
    }
}