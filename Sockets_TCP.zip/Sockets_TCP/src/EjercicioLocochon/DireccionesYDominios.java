package EjercicioLocochon;

public class DireccionesYDominios {
    private String direccion;
    private String dominio;

    DireccionesYDominios(String dir, String dom){
        this.direccion=dir;
        this.dominio=dom;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDominio() {
        return dominio;
    }

    public void setDominio(String dominio) {
        this.dominio = dominio;
    }
}