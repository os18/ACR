package Sockets_conMetodos;
import java.net.*;
import java.io.*;

public class Servidor {
    private ServerSocket servidor;
    private Socket cliente;
    private String mensaje;
    
    Servidor(){
        try{
            this.servidor=new ServerSocket(3001);
            this.cliente=servidor.accept();
            this.mensaje="";
        } catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void enviarMensaje(){
        try {
            DataOutputStream dos=new DataOutputStream(cliente.getOutputStream());
            dos.writeUTF("WTU?");
        } catch(IOException e){System.out.println(e.getMessage());}
    }
    
    public void recibirMensaje(){
        try {
            DataInputStream dis=new DataInputStream(cliente.getInputStream());
            mensaje=dis.readUTF();
            System.out.println(mensaje);
        } catch(IOException e){System.out.println(e.getMessage());}
        
    }
    
    public static void main(String args[]){
        Servidor s=new Servidor();
        do{
            s.enviarMensaje();
            s.recibirMensaje();
        }while(true);
    }
}