package Ej1_carrito_compras;
import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class Cliente {
    private ArrayList<Producto> producto;
    private String nombre;

    public Cliente(ArrayList<Producto> cliente, String nom){
        this.nombre=nom;
        this.producto=cliente;
    }
    
    public ArrayList<Producto> getProducto() {
        return producto;
    }

    public void setProducto(ArrayList<Producto> producto) {
        this.producto = producto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void pagar(){
	try {
            InetAddress address = InetAddress.getByName("127.0.0.1");
            Socket clientSocket = new Socket(address, 1234);       
            EjecutarCliente l;
            try{
                l = new EjecutarCliente(clientSocket);
                Thread t = new Thread(l);
                t.start();
            }catch(Exception e) { System.out.println(e.getMessage());}
            
            PrintWriter out =  new PrintWriter(clientSocket.getOutputStream(), true);
            out.println(this.nombre+this.producto);
            System.out.println("cliente: "+this.nombre+" favor de pasar a caja.");
            System.out.print(">"); 
            clientSocket.close();
            System.out.println("conexion terminada!");
	}catch(IOException e) { e.printStackTrace(); }
    }
}