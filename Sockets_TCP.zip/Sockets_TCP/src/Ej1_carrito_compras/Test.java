package Ej1_carrito_compras;
import java.util.ArrayList;
import java.util.Random;

public class Test{
    public static void main(String args[]){
    ArrayList <Producto> p1= new ArrayList<Producto>(); 
    ArrayList <Producto> p2= new ArrayList<Producto>(); 
    ArrayList <Producto> p3= new ArrayList<Producto>(); 
    ArrayList <Producto> p4= new ArrayList<Producto>(); 
    ArrayList <Producto> p5= new ArrayList<Producto>(); 
    ArrayList <Producto> p6= new ArrayList<Producto>(); 
    ArrayList <Producto> p7= new ArrayList<Producto>(); 
    ArrayList <Producto> p8= new ArrayList<Producto>(); 
    ArrayList <Producto> p9= new ArrayList<Producto>(); 
    ArrayList <Producto> p10= new ArrayList<Producto>(); 
    ArrayList <Producto> p11= new ArrayList<Producto>(); 
    ArrayList <Producto> p12= new ArrayList<Producto>(); 
    ArrayList <Producto> p13= new ArrayList<Producto>(); 
    ArrayList <Producto> p14= new ArrayList<Producto>(); 
                 
    Producto galletas= new Producto("Oreo", 10);
    Producto chocolateConejo= new Producto("Conejo épico", 9);
    Producto chetitos= new Producto("chetitos", 7);
    Producto GarampinadosDeNoe= new Producto("GarampinadosDeNoe", 5);
    Producto PapasLeo= new Producto("PapasLeo", 12);
    Producto RompopesAlfredo= new Producto("RompopesAlfredo", 10);
       
    p1.add(PapasLeo);
    p2.add(chocolateConejo);
    p3.add(galletas);
    p4.add(chetitos);
    p5.add(RompopesAlfredo);
    p6.add(GarampinadosDeNoe);
    p7.add(PapasLeo);
    p8.add(chocolateConejo);
    p10.add(galletas);
    p2.add(chetitos);
    p12.add(RompopesAlfredo);
    p13.add(GarampinadosDeNoe);
    p7.add(PapasLeo);
    p14.add(chocolateConejo);
    p5.add(galletas);
    p14.add(chetitos);
    p11.add(RompopesAlfredo);
    p10.add(GarampinadosDeNoe);
    p9.add(PapasLeo);
    p9.add(chocolateConejo);
    p8.add(galletas);
    p4.add(chetitos);
    p13.add(RompopesAlfredo);
    p12.add(GarampinadosDeNoe);
        
    ArrayList<Cliente> listaClientes= new ArrayList<Cliente>();
        
    Cliente c1= new Cliente(p1, "Chano");
    Cliente c2= new Cliente(p2,"Nancy");
    Cliente c3= new Cliente(p3,"Noe");
    Cliente c4= new Cliente(p4,"Santi");
    Cliente c5= new Cliente(p5,"Ivan");
    Cliente c6= new Cliente(p6,"Leo");
    Cliente c7= new Cliente(p7,"Keny");
    Cliente c8= new Cliente(p8,"Jaquez");
    Cliente c9= new Cliente(p9,"Piña");
    Cliente c10= new Cliente(p10,"Deivid");
    Cliente c11= new Cliente(p11,"Budis");
    Cliente c12= new Cliente(p12,"Reina");
    Cliente c13= new Cliente(p13,"Juan");
    Cliente c14= new Cliente(p14,"Viry"); 
    listaClientes.add(c1);
    listaClientes.add(c2);
    listaClientes.add(c3);
    listaClientes.add(c4);
    listaClientes.add(c5);
    listaClientes.add(c6);
    listaClientes.add(c7);
    listaClientes.add(c8);
    listaClientes.add(c9);
    listaClientes.add(c10);
    listaClientes.add(c11);
    listaClientes.add(c12);
    listaClientes.add(c13);
    listaClientes.add(c14);
       
    Cajero caj1=new Cajero(20,"chana");
    Cajero caj2=new Cajero(20,"chana");
    Cajero caj3=new Cajero(20,"chana");
              
    Random r= new Random();
    int x=1;
    int cajera=1;
    while(!listaClientes.isEmpty()){
        int n=r.nextInt(listaClientes.size());
        Cliente sig=listaClientes.get(n);
        listaClientes.remove(n);
        switch(cajera){
            case 1:
                caj1.getClientes().add(sig);
                break;
            case 2:
                caj2.getClientes().add(sig);                        
                break;
            case 3:                        
                caj3.getClientes().add(sig);
                break;
        }
        cajera++;
        if(cajera==4){
            cajera=1;
        }
    }
    caj1.cobrar();
    c1.pagar();
    ArrayList<Cliente> clientesillos= new ArrayList<Cliente>();
    ArrayList<Cliente> clientesillos1= new ArrayList<Cliente>();
    ArrayList<Cliente> clientesillos2= new ArrayList<Cliente>();
    }
}