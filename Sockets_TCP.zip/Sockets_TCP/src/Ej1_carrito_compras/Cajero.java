package Ej1_carrito_compras;
import java.net.*;
import java.util.*;
import java.io.IOException;

public class Cajero{
    private ArrayList<Cliente> clientes= new ArrayList<Cliente>();
    private int tiempo;
    private String nombre;

    public Cajero(int t, String n){
        this.nombre=n;
        this.tiempo=t;
    }
    
    public ArrayList<Cliente> getClientes(){
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes){
        this.clientes = clientes;
    }

    public int getTiempo(){
        return tiempo;
    }

    public void setTiempo(int tiempo){
        this.tiempo = tiempo;
    }

    public String getNombre(){
        return nombre;
    }

    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public void cobrar(){
        try{
            ServerSocket server = new ServerSocket(1234);
            System.out.println("Servidor en ejecución...\n");
            int i=0;
            while(!clientes.isEmpty()){
                EjecutarCajero w;
                try{
                    System.out.println(clientes.get(i).getNombre());
                    w = new EjecutarCajero(server.accept(), clientes.get(i));
                    Thread t = new Thread(w);
                    t.start();
                    clientes.remove(i);
                }catch(IOException e) {
                    System.out.println(e.getMessage());
                    System.exit(-1);
                }
                i++;
            }
        } catch(IOException e) {
            System.out.println(e.getMessage());
            System.exit(-1);
        }
    }
}