package Ej1_carrito_compras;

public class Producto {
    private String Nombre;
    private int precio;
    
    public Producto(String nom, int p){
        this.Nombre=nom;
        this.precio=p;
    }
    
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
}