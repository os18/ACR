package Ej1_carrito_compras;
import java.io.*;
import java.net.Socket;

public class EjecutarCajero implements Runnable{
    private Socket client;
    Cliente elCliente;
    
    EjecutarCajero(Socket client, Cliente elCliente) {      
        this.client = client;
        this.elCliente=elCliente;
        System.out.println("Conectado a: " + client);
    }

    public void run(){
        BufferedReader in = null;
        PrintWriter out = null;
        try{
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            out = new PrintWriter(client.getOutputStream(), true);
        } catch(IOException e) {
            System.out.println(e.getMessage());
            System.exit(-1);
        }

        out.println("Server-> "+client.getPort()+">>  Nombre: "+elCliente.getNombre()+"  productos: "+elCliente.getProducto());
        try {
            client.close();
            System.out.println("Chaito: " + elCliente.getNombre() + " ¡vuelva pronto!");
        } catch (IOException e) {System.out.println("Error en conexion con el cliente: " + client);}
    }
}