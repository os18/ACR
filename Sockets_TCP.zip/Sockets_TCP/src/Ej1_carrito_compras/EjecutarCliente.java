package Ej1_carrito_compras;
import java.io.*;
import java.net.*;
import java.util.logging.*;

public class EjecutarCliente implements Runnable{
    private Socket client;

    EjecutarCliente(Socket client) {
        this.client = client;
        System.out.println("En escucha con: " + client);
    }

    public void run(){
        try{
            BufferedReader in = null;
            try{
                in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            } catch(IOException e){
                System.out.println(e.getMessage());
                System.exit(-1);
            }
            client.close();
        }catch(IOException ex) {Logger.getLogger(EjecutarCliente.class.getName()).log(Level.SEVERE, null, ex);}
    }
}