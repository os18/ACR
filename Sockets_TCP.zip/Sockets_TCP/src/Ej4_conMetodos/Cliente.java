package Ej4_conMetodos;
import java.io.*;
import java.net.*;

public class Cliente {
    private InetAddress direccion;
    private Socket cliente;
    
    Cliente(){
        try{ 
            this.direccion = InetAddress.getByName("127.0.0.1");
            try{
                this.cliente = new Socket(direccion,1234);          
            } catch(IOException ex){System.out.println(ex.getMessage());}
        }catch(UnknownHostException e){ 
            System.err.println("Host no encontrado : "+e); 
            System.exit(-1);      
        }
    }
    
    public void enviarNumero(){
        try{
            DataOutputStream dos  = new DataOutputStream(cliente.getOutputStream()); 
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            dos.writeUTF(br.readLine());            
        } catch(IOException ex){System.out.println(ex.getMessage());}
    }
    
    public void recibirResultado(){
        try{
            DataInputStream dis  = new DataInputStream(cliente.getInputStream()); 
            System.out.println("Resultado = "+dis.readUTF()); 
        } catch(IOException ex){System.out.println(ex.getMessage());}
    }
    
    public static void main(String args[]){       
        Cliente c=new Cliente();
        c.enviarNumero();
        c.recibirResultado();
    }      
}