package Ej4_conMetodos;
import java.io.*;
import java.net.*;

public class Servidor {
    private ServerSocket servidor;
    private Socket cliente;
    
    Servidor(){
        try{
            servidor= new ServerSocket(1234);   
            cliente = servidor.accept();      
        }catch(IOException ie){
            System.err.println("Error al abrir el socket de servidor : " + ie); 
            System.exit(-1);
        }
    }
    
    public String calcularResultado(){
        String s="";
        try{
            DataInputStream dis  = new DataInputStream(cliente.getInputStream());      
            String entrada = dis.readUTF();   
            int numero = Integer.parseInt(entrada);
            long salida = (long)numero * (long)numero;      
            s=String.valueOf(salida);
        }catch(IOException ie){
            System.err.println("Error al abrir el socket de servidor : " + ie); 
            System.exit(-1);
        }
        return s;
    }
    
    public void enviarResultado(String s){
        try{
            DataOutputStream dos = new DataOutputStream(cliente.getOutputStream());                   
            dos.writeUTF(s);      
        }catch(IOException ie){
            System.err.println("Error al abrir el socket de servidor : " + ie); 
            System.exit(-1);
        }
    }
    
    public static void main(String args[]) {      
        Servidor s=new Servidor();
        String aux=s.calcularResultado();
        s.enviarResultado(aux);
    }      
}