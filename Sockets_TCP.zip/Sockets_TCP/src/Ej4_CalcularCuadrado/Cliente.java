package Ej4_CalcularCuadrado;
import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String args[]){       
        try{ 
            InetAddress direccion = InetAddress.getByName("127.0.0.1");
            try{
                Socket sckt = new Socket(direccion,1234);
                DataInputStream dis  = new DataInputStream(sckt.getInputStream()); 
                DataOutputStream dos  = new DataOutputStream(sckt.getOutputStream()); 
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                dos.writeUTF(br.readLine());      
                System.out.println("Resultado = "+dis.readUTF()); 
                dis.close();      
                dos.close();      
            } catch(IOException ex){System.out.println(ex.getMessage());}
        }catch(UnknownHostException e){ 
            System.err.println("Host no encontrado : "+e); 
            System.exit(-1);      
        } 
    }      
}