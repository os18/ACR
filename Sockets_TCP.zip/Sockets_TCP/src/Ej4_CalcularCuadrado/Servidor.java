package Ej4_CalcularCuadrado;
import java.io.*;
import java.net.*;

public class Servidor {
    public static void main(String args[]) {      
        try{
            ServerSocket servidor= new ServerSocket(1234);   
            Socket cliente = servidor.accept();      
            DataInputStream dis  = new DataInputStream(cliente.getInputStream());      
            DataOutputStream dos = new DataOutputStream(cliente.getOutputStream());                   
            String entrada = dis.readUTF();   
            int numero = Integer.parseInt(entrada);
            long salida = (long)numero * (long)numero;      
            String s=String.valueOf(salida);
            dos.writeUTF(s);      
            dis.close();      
            dos.close();      
            cliente.close();      
            System.out.println("Localhost: "+InetAddress.getLocalHost().toString()+" Puerto: "+cliente.getPort()+" Dirección: "+cliente.getInetAddress());
            System.out.println("Entrada = "+entrada+"\tSalida = "+salida);
        }catch(IOException ie){
            System.err.println("Error al abrir el socket de servidor : " + ie); 
            System.exit(-1);
        }
    }      
}