package Ej2_Buscaminas;
import java.util.*;
import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n,m,p;
        System.out.println("Bienvenido a buscaminas \n"+"¿Que nivel desea jugar? \n");
        System.out.println("1.Fácil \n"+"2.Intermedio \n"+"3.Avanzado");
        n = sc.nextInt();
        Tablero tab = Tiro(-1, -1, n);
        System.out.println(tab);
        while (tab.getEstadoJuego() == 0) {
            System.out.println("¿Qué desea hacer tirar o marcar? \n"+"1.Tirar \n"+"2.Marcar \n");
            n = sc.nextInt()-1;
            System.out.println("Ingrese las coordenadas");
            m=sc.nextInt()-1;
            p=sc.nextInt()-1;
            tab = Tiro(m, p, n);
            System.out.println(tab);
        }
        if(tab.getEstadoJuego() == 1) {System.out.println("Champion");
        }else{System.out.println("Looser");}
    }

    public static Tablero Tiro(int x, int y, int jugada){
        Tablero t = null;
        try{
            Socket s = new Socket(InetAddress.getByName("localhost"), 4040);
            ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
            ObjectInputStream is = new ObjectInputStream(s.getInputStream());
            os.flush();           
            Jugada j1 = new Jugada();
            j1.setTipo(jugada);
            j1.setX(x);
            j1.setY(y);
            os.writeObject(j1);
            os.flush();
            t = (Tablero) is.readObject();
            is.close();
            os.close();
            s.close();
        }catch (UnknownHostException ex) {} catch (IOException ex) {} catch (ClassNotFoundException ex) {}
        return t;
    }
}