package Ej2_Buscaminas;
import java.io.*;
import java.net.*;

public class Servidor {
    public static void main(String[] args) {
        Tablero juego = null;        
        try{
            ServerSocket ss = new ServerSocket(4040);
            while(true){
                Socket s = ss.accept();
                ObjectOutputStream os = new ObjectOutputStream(s.getOutputStream());
                ObjectInputStream is = new ObjectInputStream(s.getInputStream());
                os.flush();
                Jugada j = (Jugada) is.readObject();
                if(j != null) {
                    if(j.getX() < 0 && j.getY() < 0) {
                        System.out.println("Nuevo juego");
                        juego = new Tablero(j.getTipo());
                    }else{
                        juego.hazJugada(j.getX(), j.getY(), j.getTipo());
                        if(juego.getEstadoJuego() == -1) {
                            System.out.println("El jugador perdió");
                        }
                    }
                }
                os.writeObject(juego);
                os.flush();
                is.close();
                os.close();
                s.close();
            }
        }catch(ClassNotFoundException ce){} catch (IOException ex) {}
    }
}