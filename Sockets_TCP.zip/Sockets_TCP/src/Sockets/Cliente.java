package Sockets;
import java.io.*;
import java.net.*;

public class Cliente {
    public static void main(String args[]){
        try{
            String mensaje="";
            Socket cliente=new Socket("127.0.0.1", 3000); //conectando al puerto y dirección del servidor
            do{ //enviar mientras el mensaje sea diferente de "fin"
                DataInputStream dis=new DataInputStream(cliente.getInputStream()); //para leer
                DataOutputStream dos=new DataOutputStream(cliente.getOutputStream()); //para enviar
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); //objeto que permite almacenar lo que escriba el cliente     
                System.out.println(dis.readUTF()); //primero se imprime el mensaje del servidor
                mensaje=br.readLine();//se envia respuesta en el contenedor 
                dos.writeUTF(mensaje); //se pasa por el canal de comunicación
            }while(!mensaje.startsWith("fin"));    
        }catch(IOException e){System.out.println(e.getMessage());}
    }
}