package Sockets;
import java.io.*;
import java.net.*;

public class Servidor {
    public static void main(String args[]){
        try{
            String mensaje=""; 
            ServerSocket servidor=new ServerSocket(3000); //creando el socket del servidor
            Socket cliente=servidor.accept(); //ligando con el cliente
            do{ //escuchando 
                DataInputStream dis=new DataInputStream(cliente.getInputStream()); //para recibir
                DataOutputStream dos=new DataOutputStream(cliente.getOutputStream()); //para enviar
                dos.writeUTF("¿Qué pex? "); //enviando mensaje al cliente 
                mensaje=dis.readUTF(); //leyendo la respuesta del cliente
                System.out.println(mensaje); //mostrando la respuesta del cliente
            }while(1>0);
        }catch(IOException e){System.out.println(e.getMessage());}
    }
}