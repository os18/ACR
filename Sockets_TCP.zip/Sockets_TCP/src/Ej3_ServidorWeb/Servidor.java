package Ej3_ServidorWeb;
import java.io.*;
import java.net.*;

public class Servidor {
    private static ServerSocket ss;

    public static void main(String [] args) {
        try {
            ss = new ServerSocket(12345);
            for (;;) {
                Socket s = ss.accept();
                new Peticion(s).start();
            }
        } catch (IOException ex) {}
    }
}